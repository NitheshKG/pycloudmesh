class AWSReservationService:
    AMAZONEC2 =  "AmazonEC2"
    AMAZONRDS = "AmazonRDS"
    AMAZONREDSHIFT = "AmazonRedshift"
    AMAZONELASTICCACHE = "AmazonElasticCache"
    AMAZONOPENSEARCHSERVICE = "AmazonOpenSearchService"
